(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(root)_page_tsx_e19524._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(root)_page_tsx_e19524._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_ci_index_mjs_e4544c._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_ti_index_mjs_c5457c._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_e86d95._.js",
    "static/chunks/_3d4f82._.js"
  ],
  "source": "dynamic"
});
