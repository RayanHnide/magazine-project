(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(vote)_vote_page_tsx_eb986b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(vote)_vote_page_tsx_eb986b._.js",
  "chunks": [
    "static/chunks/node_modules_3dcbf5._.js",
    "static/chunks/_fe94d0._.js"
  ],
  "source": "dynamic"
});
