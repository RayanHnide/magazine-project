(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(vote)_votingResults_page_tsx_eb986b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(vote)_votingResults_page_tsx_eb986b._.js",
  "chunks": [
    "static/chunks/node_modules_@mui_system_esm_c9ed63._.js",
    "static/chunks/node_modules_@mui_material_b6a822._.js",
    "static/chunks/node_modules_@mui_x-charts_507742._.js",
    "static/chunks/node_modules_@react-spring_core_dist_react-spring_core_modern_mjs_65a810._.js",
    "static/chunks/node_modules_@popperjs_core_lib_b9b8df._.js",
    "static/chunks/node_modules_539b03._.js",
    "static/chunks/_f7e143._.js"
  ],
  "source": "dynamic"
});
