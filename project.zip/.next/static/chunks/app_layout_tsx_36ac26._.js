(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_36ac26._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_36ac26._.js",
  "chunks": [
    "static/chunks/[root of the server]__1cab27._.css",
    "static/chunks/node_modules_next_9088cc._.js",
    "static/chunks/_10fcad._.js"
  ],
  "source": "dynamic"
});
